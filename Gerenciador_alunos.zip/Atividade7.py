# gerenciador_alunos.py

alunos = {}

def adicionar_aluno():
    matricula = input("Digite o número de matrícula do aluno: ")
    nome = input("Digite o nome do aluno: ")
    alunos[matricula] = nome
    print(f"Aluno adicionado com sucesso: {nome}, matrícula: {matricula}")

def remover_aluno():
    matricula = input("Digite o número de matrícula do aluno a ser removido: ")
    if matricula in alunos:
        del alunos[matricula]
        print("Aluno removido com sucesso.")
    else:
        print("Aluno não encontrado.")

def atualizar_aluno():
    matricula = input("Digite o número de matrícula do aluno a ser atualizado: ")
    if matricula in alunos:
        novo_nome = input("Digite o novo nome do aluno: ")
        alunos[matricula] = novo_nome
        print("Nome do aluno atualizado com sucesso.")
    else:
        print("Aluno não encontrado.")

def ver_alunos():
    print("Lista de alunos:")
    for matricula, nome in alunos.items():
        print(f"Matrícula: {matricula}, Nome: {nome}")

if __name__ == "__main__":
    while True:
        print("\nMenu:")
        print("1. Adicionar Aluno")
        print("2. Remover Aluno")
        print("3. Atualizar Aluno")
        print("4. Ver Alunos")
        print("5. Sair")

        escolha = input("Escolha uma opção: ")

        if escolha == "1":
            adicionar_aluno()
        elif escolha == "2":
            remover_aluno()
        elif escolha == "3":
            atualizar_aluno()
        elif escolha == "4":
            ver_alunos()
        elif escolha == "5":
            print("Saindo...")
            break
        else:
            print("Opção inválida. Por favor, escolha uma opção válida.")
